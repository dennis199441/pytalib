# pytalib
Technical Analysis Library for CMSC5720
