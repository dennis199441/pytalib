from .base import VolumeIndicator

class AccumulationDistributionLine(VolumeIndicator):
	
	def reset(self, prices):
		pass
	
	def calculate(self):
		
		return 0

class EaseOfMovement(VolumeIndicator):
	
	def reset(self, prices):
		pass
	
	def calculate(self):
		
		return 0

class ForceIndex(VolumeIndicator):
	
	def reset(self, prices):
		pass
	
	def calculate(self):
		
		return 0

class NegativeVolumeIndex(VolumeIndicator):
	
	def reset(self, prices):
		pass
	
	def calculate(self):
		
		return 0

class OnBalanceVolume(VolumeIndicator):
	
	def reset(self, prices):
		pass
	
	def calculate(self):
		
		return 0

class PutCallRatio(VolumeIndicator):
	
	def reset(self, prices):
		pass
	
	def calculate(self):
		
		return 0


class VolumePriceTrend(VolumeIndicator):
	
	def reset(self, prices):
		pass
	
	def calculate(self):
		
		return 0



