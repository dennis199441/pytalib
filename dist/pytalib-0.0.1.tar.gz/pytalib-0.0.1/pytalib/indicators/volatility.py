from .base import VolatilityIndicator

class AverageTrueRange(VolatilityIndicator):

	def reset(self, prices):
		pass

	def calculate(self):
		
		return 0

class BollingerBands(VolatilityIndicator):

	def reset(self, prices):
		pass

	def calculate(self):
		
		return 0

class DonchianChannel(VolatilityIndicator):

	def reset(self, prices):
		pass

	def calculate(self):
		
		return 0

class KeltnerChannel(VolatilityIndicator):

	def reset(self, prices):
		pass

	def calculate(self):
		
		return 0

class StandardDeviation(VolatilityIndicator):

	def reset(self, prices):
		pass
		
	def calculate(self):
		
		return 0


